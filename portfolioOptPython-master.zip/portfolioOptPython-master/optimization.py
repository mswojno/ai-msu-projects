#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Feb 22 20:58:02 2019

@author: MatthewSWojno
"""
import cvxpy as cp
import numpy as np
import matplotlib.pyplot as plt
import pandas
import quandl

#######################
# No holds bar
#######################
w = cp.Variable(N)
gamma = cp.Parameter(nonneg=True)
# Problem:ret
# ret is the expected return for the portfolio, how would you calculate that?
# CENSORED!!CENSORED!!CENSORED!!CENSORED!!
#ret =
# Problem:risk
# risk is the cov matrix for the portfolio, how would you calculate that?
# CENSORED!!CENSORED!!CENSORED!!CENSORED!!
#risk =
# Problem:constraint_1
# write the constraints for long only holds
# CENSORED!!CENSORED!!CENSORED!!CENSORED!!
constraints = [ ]
objective = cp.Maximize(ret)
prob = cp.Problem(objective,constraints)
