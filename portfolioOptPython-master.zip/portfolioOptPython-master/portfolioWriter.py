#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Feb 20 14:00:47 2019

@author: MatthewSWojno
"""
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

def portfolioWriter(filename,table,market='S&P 500'):
    f = open(filename,'w')
    f.write('#######################\n')
    f.write('# Market: ' + market +'\n')
    f.write('# Dates: ' + str(table.index[0])+' '+str(table.index[-1])+'\n')
    f.write('# Socks: '+np.array2string(table.columns)+'\n')
    f.write('#######################\n')
    f.write(' '+str(len(table.columns))+'\n')
    f.write('#######################\n')
    f.closed
    # Problem:get_returns
    # calculate the returns
    # CENSORED!!CENSORED!!CENSORED!!CENSORED!!
    data=table
    N = data.shape[0]
    returnsDataFrame = (data[1:N].values - data[:N-1].values) / (data[:N-1].values)
    returnsDataFrame = pd.DataFrame(returnsDataFrame, columns=[data.columns])
    returnsDataFrame = returnsDataFrame.fillna(0)
    returns =  np.array(returnsDataFrame.mean())
    stds = np.array(returnsDataFrame.std())
    
    #
    # Problem:get_stds
    # calculate the standard deviation
    # CENSORED!!CENSORED!!CENSORED!!CENSORED!!
    # of the actual returns not the data
    #stds = [];
    #for x in range(0,len(returns)):
        #stds.append(np.array(np.std(returnsDataFrame.iloc[:x])))
    #stdsDataFrame = pd.DataFrame(stds, columns=[data.columns])
    #stdsDataFrame = stdsDataFrame.fillna(0)
    #stds = np.array(stdsDataFrame)
    #returns = np.round(returns, 5)
    #stds = np.round(stds, 5)
    for i in range(0,len(returns)):
        #print(' '+str(returns[i])+' '+str(stds[i])+'\n')
        f.write(' '+str(returns[i])+' '+str(stds[i])+'\n')
    f.write('#######################\n')
    # Problem:corr
    # calculate the correlation matrix
    # CENSORED!!CENSORED!!CENSORED!!CENSORED!!
    corrMat = table.corr()
    for (ii,jj), x in np.ndenumerate(corrMat):
        f.write(' ' + str(ii+1)+' '+str(jj+1)+' '+str(x)+'\n')
    f.write('#######################\n')
            

dateparse = lambda x: pandas.datetime.strptime(x, '%Y-%m-%d')
stock_table = pandas.read_csv('stock_table.csv',index_col='date',date_parser=dateparse)
portfolioWriter('myport.in',stock_table)