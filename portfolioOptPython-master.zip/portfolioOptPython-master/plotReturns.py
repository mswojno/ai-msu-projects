#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Feb 14 09:15:22 2019

@author: MatthewSWojno
"""
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
def plotReturns(stock_table,fontsize=12,figsize=(10, 5)):
    # Problem:get_returns
    # calculate the returns
    # CENSORED!!CENSORED!!CENSORED!!CENSORED!!
    data = stock_table
    N = data.shape[0]
    returns = (data[1:N].values - data[:N-1].values) / (data[:N-1].values)
    returns = pd.DataFrame(returns, columns=[data.columns])
    returns = returns.fillna(0)
        
    plt.figure(figsize=figsize)
    for c in returns.columns.values:
        plt.plot(returns.index, returns[c], lw=3, alpha=0.8,label=c)
    plt.legend(loc='lower right', fontsize=fontsize)
    plt.ylabel('daily returns')
    
dateparse = lambda x: pandas.datetime.strptime(x, '%Y-%m-%d')
stock_table = pandas.read_csv('stock_table.csv',index_col='date',date_parser=dateparse)
plotReturns(stock_table);
