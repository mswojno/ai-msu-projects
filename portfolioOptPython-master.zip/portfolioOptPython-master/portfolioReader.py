#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Feb 21 12:01:05 2019

@author: MatthewSWojno
"""
import numpy as np
import matplotlib.pyplot as plt
import pandas

def portfolioReader(filename):
    #######################
    # Skip the comments
    #######################
    def skipComments(idx,content):
        while content[idx][0]=='#':
            idx += 1
            continue
        return idx
    #######################
    with open(filename) as f:
        read_data = f.read().split('\n')
    f.closed
    idx = 0
    idx = skipComments(idx,read_data)
    # define arrays
    N = int(read_data[idx].strip())
    idx += 1
    ret = np.zeros(N)
    sdv = np.zeros(N)
    covariance_mat = np.zeros([N,N])
    idx = skipComments(idx,read_data)
    # need an array of 6 values. Those six would have those arrays packed
    # populate return and sdv
    # Problem:ret_sdv
    #for ii in range (0,len()):
        # CENSORED!!CENSORED!!CENSORED!!CENSORED!!
        # read the contents into the 2 np.arrays
        # wants 2 arrays of 6 that has mean return and std mean
    r_outer_num = [];
    s_outer_num = [];
    
    while read_data[idx][0] != '#':
        print(idx)
        print(read_data[idx].split("]")[0])
        print(read_data[idx].split("]")[1])
        r = read_data[idx].split("]")[0]
        s = read_data[idx].split("]")[1]
        r = r.strip().strip("[")
        s = s.strip().strip("[")
        r = r.split()
        s = s.split()
        r_num = []
        for num in r:
            r_num.append(float(num))
        s_num = []
        for num in s:
            if (num == 'nan'):
                s_num.append(float(0))
            else:
                s_num.append(float(num))
        
        r_outer_num.append(r_num);
        s_outer_num.append(s_num);
        idx+=1
    
    print(r_outer_num)
    idx += N
    idx = skipComments(idx,read_data)
    # populate the cov
    # Yahoo finance explains how:
    # https://finance.yahoo.com/news/calculating-covariance-stocks-170000325.html
    while read_data[idx][0] != '#':
            II,JJ,VAL = read_data[idx].strip().split(' ')
            # Problem:cov
            # CENSORED!!CENSORED!!CENSORED!!CENSORED!!
            idx += 1
    return N,ret,sdv,covariance_mat

N,expected_ret,sdv_arr,covariance_mat = portfolioReader('./myport.in')